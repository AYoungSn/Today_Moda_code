import React from 'react';
import {
  StyleSheet,
} from 'react-native';

export default class Shopping extends React.Component{
  render(){
    return (
      <>
      </>
    );
  }
};